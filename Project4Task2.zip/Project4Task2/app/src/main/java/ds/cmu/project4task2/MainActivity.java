package ds.cmu.project4task2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.net.UnknownHostException;

/**
 * Name: Yanxuan Dong
 * Andrew ID: yanxuand
 */
public class MainActivity extends AppCompatActivity {

    private EditText seriesIdEditText;
    private Button getDataButton;
    private TextView seriesInfoTextView;
    private TextView observationsTextView;

    // Replace with your Codespace URL when deployed
    private static final String API_URL = "https://solid-goggles-v6gx6vxgxwvpf6qqj-8080.app.github.dev/api/";
//    private static final String API_URL = "http://127.0.0.1:8080/api";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        seriesIdEditText = findViewById(R.id.seriesIdEditText);
        getDataButton = findViewById(R.id.getDataButton);
        seriesInfoTextView = findViewById(R.id.seriesInfoTextView);
        observationsTextView = findViewById(R.id.observationsTextView);

        // Set up button click listener
        getDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String seriesId = seriesIdEditText.getText().toString().trim();
                if (!seriesId.isEmpty()) {
                    new FetchFredDataTask().execute(seriesId);
                } else {
                    Toast.makeText(MainActivity.this, "Please enter a series ID", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private class FetchFredDataTask extends AsyncTask<String, Void, String> {
        @Override
        protected void onPreExecute() {
            // Show loading indicators
            seriesInfoTextView.setText("Loading series information...");
            observationsTextView.setText("");
        }

        @Override
        protected String doInBackground(String... params) {
            String seriesId = params[0];
            String fullUrl = null;
            Log.d("API_DEBUG", "Attempting to call: " + fullUrl);  // Add this line
            String result = "";

            try {
                // Create URL with parameters
                URL url = new URL(API_URL + "?seriesId=" + URLEncoder.encode(seriesId, "UTF-8"));

                // Create connection with timeout
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000); // 5 second timeout
                connection.setReadTimeout(5000);

                // Check response code
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Read response
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;
                    StringBuilder response = new StringBuilder();

                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    reader.close();
                    result = response.toString();
                } else {
                    result = "Error: Server returned code " + responseCode;
                }

            } catch (SocketTimeoutException e) {
                e.printStackTrace();
                result = "Error: Server connection timeout. Please try again later.";
            } catch (UnknownHostException e) {
                e.printStackTrace();
                result = "Error: Cannot reach server. Please check your internet connection.";
            } catch (Exception e) {
                e.printStackTrace();
                result = "Error: " + e.getMessage();
            }

            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                if (result.startsWith("Error:")) {
                    seriesInfoTextView.setText(result);
                    return;
                }

                // Parse JSON response
                JSONObject jsonResponse = new JSONObject(result);

                // Check for error in response
                if (jsonResponse.has("error")) {
                    seriesInfoTextView.setText("Error: " + jsonResponse.getString("error"));
                    return;
                }

                // Display series information
                if (jsonResponse.has("seriesInfo")) {
                    JSONObject seriesInfo = jsonResponse.getJSONObject("seriesInfo");
                    StringBuilder infoText = new StringBuilder();
                    infoText.append("Series: ").append(seriesInfo.getString("title")).append("\n");
                    infoText.append("Frequency: ").append(seriesInfo.getString("frequency")).append("\n");
                    infoText.append("Units: ").append(seriesInfo.getString("units")).append("\n");
                    seriesInfoTextView.setText(infoText.toString());
                }

                // Display observations
                if (jsonResponse.has("observations")) {
                    JSONArray observations = jsonResponse.getJSONArray("observations");
                    StringBuilder obsText = new StringBuilder("Recent Data Points:\n\n");

                    for (int i = 0; i < observations.length(); i++) {
                        JSONObject obs = observations.getJSONObject(i);
                        obsText.append("Date: ").append(obs.getString("date"))
                                .append(", Value: ").append(obs.getString("value"))
                                .append("\n");
                    }

                    observationsTextView.setText(obsText.toString());
                }

            } catch (JSONException e) {
                e.printStackTrace();
                seriesInfoTextView.setText("Error parsing response: Invalid data format");
            } catch (Exception e) {
                e.printStackTrace();
                seriesInfoTextView.setText("Error: " + e.getMessage());
            }
        }
    }
}